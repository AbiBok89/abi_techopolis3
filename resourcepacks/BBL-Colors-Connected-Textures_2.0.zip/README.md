This Resource Pack allows for some textures in the BBL Colors mod to work with Fusion(Connected Textures)

Requires both BBL Colors and Fusion to work correctly 
